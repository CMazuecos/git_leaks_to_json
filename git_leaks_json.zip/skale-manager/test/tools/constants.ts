const rewardPeriod = 3600;
const deltaPeriod = 300;
const checkTime = 120;

export { rewardPeriod, deltaPeriod, checkTime };