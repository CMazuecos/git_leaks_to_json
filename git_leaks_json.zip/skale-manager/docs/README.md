This folder contains specification documents (docs/specs), template helper and 
template files (\*.hbs and helpers.js) for generating documentation based on 
NatSpec using solidity-docgen.

Generated documentation is placed in docs/api/.
